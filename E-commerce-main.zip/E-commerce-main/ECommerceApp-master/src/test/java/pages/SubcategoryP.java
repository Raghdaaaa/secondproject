package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SubcategoryP extends Page{

    public SubcategoryP(WebDriver driver) {
        super(driver);
    }

    public By subCategories(){
        return By.className("sub-category-item");
    }
}
